#SingleInstance force
#NoEnv
SendMode Input
SetKeyDelay, 10
WinTitle := "Oracle Fusion Middleware Forms Services:  Open > SHATRNS"
WinWait, %WinTitle%
WinActivate, %WinTitle%
WinWaitActive, %WinTitle%

Send, TRSV{Tab}22110{Tab}{Tab}4.0{Tab}N{Down}{Space}{Tab}
Send, TRSV{Tab}22160{Tab}{Tab}4.0{Tab}N{Down}{Space}{Tab}
Send, CTPV{Tab}21100{Tab}{Tab}4.6{Tab}N{Down}{Space}{Tab}
Send, TVE{Tab}21110{Tab}{Tab}4.6{Tab}N{Down}{Space}{Tab}
Send, TRSV{Tab}22210{Tab}{Tab}4.3{Tab}N{Down}{Space}{Tab}
Send, CTPV{Tab}22100{Tab}{Tab}4.4{Tab}N{Down}{Space}{Tab}
Send, TVE{Tab}21100{Tab}{Tab}4.6{Tab}N{Down}{Space}{Tab}
Send, TVE{Tab}21120{Tab}{Tab}3.9{Tab}N{Down}{Space}{Tab}
Send, TRSV{Tab}22100{Tab}{Tab}4.8{Tab}N{Down}{Space}{Tab}
Send, TRSV{Tab}22260{Tab}{Tab}4.9{Tab}N{Down}{Space}{Tab}
Send, CTPV{Tab}22120{Tab}{Tab}4.7{Tab}N{Down}{Space}{Tab}
Send, TRSV{Tab}22230{Tab}{Tab}4.3{Tab}N{Down}{Space}{Tab}
Send, TRSV{Tab}22340{Tab}{Tab}4.0{Tab}N{Down}{Space}{Tab}
Send, TRSV{Tab}22120{Tab}{Tab}4.3{Tab}N{Down}{Space}{Tab}
Send, CTPV{Tab}22130{Tab}{Tab}3.7{Tab}N{Down}{Space}{Tab}
Send, CTPV{Tab}22320{Tab}{Tab}4.1{Tab}N{Down}{Space}{Tab}
Send, TRSV{Tab}22250{Tab}{Tab}4.3{Tab}N{Down}{Space}{Tab}
Send, TRSV{Tab}22240{Tab}{Tab}4.0{Tab}N{Down}{Space}{Tab}
Send, TRSV{Tab}22280{Tab}{Tab}3.8{Tab}N{Down}{Space}{Tab}
Send, TRSV{Tab}22290{Tab}{Tab}5.0{Tab}N{Down}{Space}{Tab}
Send, CTPV{Tab}22170{Tab}{Tab}4.5{Tab}N{Down}{Space}{Tab}
Send, AEV{Tab}22440{Tab}{Tab}4.8{Tab}N{Down}{Space}{Tab}
Send, TRSV{Tab}22300{Tab}{Tab}4.0{Tab}N{Down}{Space}{Tab}
Send, CTPV{Tab}22220{Tab}{Tab}4.3{Tab}N{Down}{Space}{Tab}
Send, CTPV{Tab}22110{Tab}{Tab}4.6{Tab}N{Down}{Space}{Tab}
Send, CTPV{Tab}22150{Tab}{Tab}4.5{Tab}N{Down}{Space}{Tab}
Send, CTPV{Tab}22180{Tab}{Tab}5.0{Tab}N{Down}{Space}{Tab}
Send, CTPV{Tab}22190{Tab}{Tab}3.6{Tab}N{Down}{Space}{Tab}
Send, CTPV{Tab}22200{Tab}{Tab}3.6{Tab}N
